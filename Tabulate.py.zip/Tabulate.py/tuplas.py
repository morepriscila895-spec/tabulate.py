from tabulate import tabulate

# Tabla 1: Productos (tuplas)
productos = (
    (101, "Laptop", 2500, 100),
    (102, "Mouse", 50, 150),
    (103, "Teclado", 120, 175),
    (104, "Monitor", 800, 220),
    (105, "Impresora", 600, 185)
)

print("TABLA DE PRODUCTOS")
print(tabulate(productos,
               headers=["Código", "Producto", "Precio", "stock"],
               tablefmt="grid"))

# Tabla 2: Cursos (tuplas)
cursos = (
    (110, "Python", 40),
    (120, "SQL", 30),
    (130, "Visual", 35),
    (140, "Java", 45),
    (140, "Redes", 25)
)

print("\nTABLA DE CURSOS")
print(tabulate(cursos,
               headers=["Código", "Curso", "Horas"],
               tablefmt="grid"))
